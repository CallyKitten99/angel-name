Follow steps in order:

- Run 'PDP11.exe'
- Copy and paste commands from 'boot.txt' into the terminal (right click is terminal's paste).
- When prompted, enter 'unix' exactly and press ENTER.
- When prompted again, enter 'root'.

You are now booted into the PDP11.

Commands:

ls    - list directory contents
cat   - display file contents
chdir - change directory
mkdir - make directory
rm    - remove file
rmdir - remove directory
cc    - compile C source
ed    - edit file

To find the angelname program, enter the commands:

chdir proj/angelname
angelname

To view the angelname program source, run the commands:

chdir proj/angelname
ed angelname.c

To compile the sourcec, run the command:

cc angelname.c -O
mv a.out angelname
strip angelname

^ These commands will compile the file with optimisations enabled, rename the
output program and then strip symbols out to reduce the executable's size.

Visit   http://aiju.de/code/pdp11/faq
for more extensive help and tutorials.